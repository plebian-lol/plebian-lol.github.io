<b> bold </b>
<i> italic </i>
<u> underline </u>
*bold*
_italic_
~doorstreept~
FF0000 Rood 00FF00 Groen 0000FF Blauw 
<font size="20"><strong><font color="#FF0000"> Text Groot (Rood)</font></strong></font>
