<b> bold </b>
<i> italic </i>
<u> underline </u>
*bold*
_italic_
~Crossed~
FF0000 Red 00FF00 Green 0000FF Blue 
<font size="20"><strong><font color="#FF0000">BigText - LOL</font></strong></font>
